

// No duplamente encadeado

public class No {
	public int dado;
	public No prox;
	public No ant;
	
//	Construtor
	public No(int elem) {
		this.dado = elem;
		this.prox = null;
		this.ant = null;
	}
	
}
