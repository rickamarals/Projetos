
public class Teste {

	public static void main(String[] args) {
		ListaDupla l1 = new ListaDupla();
		l1.add(10, 0);
		l1.add(9, 0);
		l1.add(11, 0);
		l1.add(22, 0);
		l1.add(8, 0);
		l1.add(0, 0);
		l1.add(7, 0);
		l1.add(6, 0);
		l1.add(5, 0);

		l1.maiornumero(7);

	}

}
