
public class Teste {

	public static void main(String[] args) {
		Fila fila01 = new Fila(10);
		ABB arvore01 = new ABB();

		fila01.entra(0);
		fila01.entra(5);
		fila01.entra(6);
		fila01.entra(8);
		fila01.entra(9);
		fila01.entra(15);
		fila01.entra(21);
		fila01.entra(12);
		fila01.entra(18);
		fila01.entra(19);
		System.out.println("Tamanho da Fila: " + fila01.tamanho());
		arvore01.adicionar(fila01);
		System.out.println("Tamanho da Fila: " + fila01.tamanho());

	}
}
