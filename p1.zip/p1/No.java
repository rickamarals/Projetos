// No para �rvore bin�ria de char

public class No {
	public int dado;
	public No dir;
	public No esq;

	public No(int elem) {
		this.dado = elem;
		this.dir = null;
		this.esq = null;
	}
}
